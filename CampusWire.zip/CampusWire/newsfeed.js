// JavaScript for dynamic newsfeed
document.addEventListener('DOMContentLoaded', () => {
    const feed = document.getElementById('feed');
    
    // Simulating user's followed interests
    const followedInterests = ['Tech Club', 'Sports', 'Art Club'];

    // Simulating newsfeed data
    const newsData = [
        {
            title: "Tech Club Coding Workshop",
            date: "October 24, 2024",
            description: "Join us this Friday for an exciting coding workshop. Enhance your programming skills!"
        },
        {
            title: "Inter-University Basketball Tournament",
            date: "October 26, 2024",
            description: "Get ready to support our university's basketball team this weekend."
        },
        {
            title: "Virtual Art Exhibition",
            date: "October 23, 2024",
            description: "Submit your artwork and join our online exhibition this weekend."
        },
        {
            title: "Climate Change Seminar",
            date: "October 25, 2024",
            description: "Join us for a seminar on climate change and its impact on the environment."
        }
    ];

    // Filtering news based on followed interests
    const filteredNews = newsData.filter(item => {
        return followedInterests.some(interest => item.title.includes(interest));
    });

    // Rendering news to the feed
    filteredNews.forEach(newsItem => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('feed-item');
        
        const title = document.createElement('h3');
        title.innerText = newsItem.title;
        
        const date = document.createElement('p');
        date.innerText = `Date: ${newsItem.date}`;
        
        const description = document.createElement('p');
        description.innerText = newsItem.description;
        
        itemDiv.appendChild(title);
        itemDiv.appendChild(date);
        itemDiv.appendChild(description);
        
        feed.appendChild(itemDiv);
    });
});
